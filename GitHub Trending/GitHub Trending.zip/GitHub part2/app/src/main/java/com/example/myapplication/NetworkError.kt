package com.example.myapplication

import GitHub.Repo
import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import com.example.m.TestNetworking

// most code gotten from: https://developer.android.com/guide/topics/ui/dialogs#kotlin
class NetworkError: DialogFragment(){
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            // Use the Builder class for convenient dialog construction
            val builder = AlertDialog.Builder(it)
            builder.setMessage("Network Error Occured")
                .setPositiveButton("Refresh",
                    DialogInterface.OnClickListener { dialog, id ->
                        //TestNetworking().getGitHub((activity as RepoListFragment).getSearchText(), activity as RepoListFragment)
                        val currFrag = ((activity as MainActivity).currentFrag as RepoListFragment)
                        currFrag.getNetworkRequest(currFrag.getSearchText())
                        currFrag.refresh.setRefreshing(false)
                    })
            // Create the AlertDialog object and return it
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}