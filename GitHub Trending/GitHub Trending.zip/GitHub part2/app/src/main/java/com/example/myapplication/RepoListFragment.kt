package com.example.myapplication

import GitHub.Repo
import GitHub.RepoContainer
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.get
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.m.TestNetworking
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

interface OnRepoItemSelectedListener{
    fun onRepoItemPicked(repo:Repo);
}
//DEFINITELY NOT THE RIGHT WAY TO DO THIS LOL
class RepoListFragment : Fragment(), AdapterCommunication {
    lateinit var recyclerView: RecyclerView
    lateinit var viewAdapter: RecyclerView.Adapter<*>
    lateinit var viewManager: RecyclerView.LayoutManager
    var myDataset: RepoContainer = RepoContainer()
    lateinit var text: EditText
    lateinit var refresh: SwipeRefreshLayout
    var time:Int = 0
    lateinit var fragView: View
    lateinit var watch : CoroutineScope
    override var position = 0
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        fragView = inflater.inflate(R.layout.repo_list_frag, container, false)
        //return inflater.inflate(R.layout.repo_list_frag, container, false)
        text = fragView.findViewById<View>(R.id.search) as EditText
        refresh = fragView.findViewById<View>(R.id.swiperefresh) as SwipeRefreshLayout
        viewManager = LinearLayoutManager(context)
        viewAdapter = MyAdapter(myDataset,this)
        //NOTE: with android studio 3.6 and higher, the view binding feature can replace findViewById().
        //Consider using view binding instead of findViewById()
        recyclerView = fragView.findViewById<RecyclerView>(R.id.my_recycler_view)?.apply{
            //use this setting to improve performance if you know
            //that changes in content do not change the layout size of the RecyclerView
            setHasFixedSize(true)

            //use a linear layout manager
            layoutManager = viewManager

            //specify an viewAdapter (see also next example)
            adapter = viewAdapter

        }!!
        CoroutineScope(Dispatchers.IO).launch{
            TestNetworking().getGitHub("Kotlin",this@RepoListFragment)
        }
        return fragView
    }
    fun getSearchText():String{
        return text.getText().toString()
    }
    fun resetMinutesAgo(){
        (fragView.findViewById<View>(R.id.minutesAgo) as TextView).text="Refreshed 0 minutes ago."
        time = 0
    }
    fun networkDialog(){
        val newFragment = NetworkError()
        newFragment.show(activity?.supportFragmentManager!!, "missiles")
    }
    fun getNetworkRequest(search:String){
        CoroutineScope(Dispatchers.IO).launch{
            TestNetworking().getGitHub(search,this@RepoListFragment)
        }
    }
    override fun onResume() {
        super.onResume()
        Log.i("onResume", viewAdapter.itemCount.toString())
        class textWatcher(myActivity: RepoListFragment) : TextWatcher {
            var myActivity: RepoListFragment = this@RepoListFragment
            override fun afterTextChanged(p0: Editable?) {
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if (myActivity.myDataset.items.size > 0 && !myActivity.myDataset.items[0].name.equals(
                        "LOADING..."
                    )
                ) {
                    if (p0 != null && !p0.toString().equals("")) {
                        //CoroutineScope(Dispatchers.IO).launch{
                            //TestNetworking().getGitHub(text.getText().toString(),this@RepoListFragment)
                        //}
                        getNetworkRequest(text.getText().toString())
                        (getView()?.findViewById<View>(R.id.topRepos) as TextView).text =
                            "top " + p0.toString() + " repos in past 24 hours"
                    }
                }
            }

        }
        text.addTextChangedListener(textWatcher(this@RepoListFragment))
        refresh.setOnRefreshListener(object : SwipeRefreshLayout.OnRefreshListener {
            override fun onRefresh() {
                Log.i("OnRefresh", text.text.toString())
                //CoroutineScope(Dispatchers.IO).launch{
                    //TestNetworking().getGitHub(text.getText().toString(),this@RepoListFragment)
                //}
                getNetworkRequest(text.getText().toString())
                //TestNetworking().getGitHub(text.getText().toString(), this@MainActivity)
                refresh.setRefreshing(false)
            }
        })
        //broken code
//        watch = CoroutineScope(Dispatchers.Main)
//        watch.launch {
//            while (true) {
//                time += 1
//                if (time == 1) {
//                    (getView()?.findViewById<View>(R.id.minutesAgo) as TextView).text =
//                        "Refreshed " + time + " minute ago"
//                } else {
//                    (getView()?.findViewById<View>(R.id.minutesAgo) as TextView).text =
//                        "Refreshed " + time + " minutes ago"
//                }
//
//                delay(60000)
//            }
//        }
        //adds the clicking and scrolling mechanics properly. (Not sure if this is the best way to do it.
        recyclerView.addOnItemTouchListener(object : RecyclerView.OnItemTouchListener{
            var scrolling = false
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                //Log.i("RecyclerView:","touch intercepted")
                if(e.getAction() == android.view.MotionEvent.ACTION_UP){
                    if(scrolling){
                        scrolling = false
                    }
                    else{
                        Log.i("RecyclerView:","Released")
                        Log.i("Clicked",position.toString())
                        (activity as OnRepoItemSelectedListener).onRepoItemPicked(myDataset.items[position])

                    }
                }
                else if((e.getAction() == android.view.MotionEvent.ACTION_DOWN)){
                    //Log.i("RecyclerView:","Pressed")
                }
                else{
                    scrolling = true
                    //Log.i("RecyclerView:","Scrolling")
                    return false
                }
                return false
            }

            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                if(e.getAction() == android.view.MotionEvent.ACTION_UP){
                    //Log.i("RecyclerView:","Released2")
                }
            }

            override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {
            }
        })
    }

    override fun onPause() {
        super.onPause()
        Log.i("paused","")
    }
}