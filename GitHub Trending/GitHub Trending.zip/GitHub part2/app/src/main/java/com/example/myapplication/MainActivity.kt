package com.example.myapplication

import GitHub.Repo
import android.app.ActionBar
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.activity_main.*

/*
    things to add:
    1. add a fragment system so that you can see more information about the repos, you will
    need to implement live data, back button.
    2. lookover coroutine scopes to make sure that they are properly written (in TestNetworking)
 */
/*
known bugs: 1.when quickly typing in searches, then fully deleting them, the app will break and not search anymore.
(I think this is fixed).
2.The layout that displays the repos is jerry rigged with a Linear Layout when a Grid Layout would be prefered.
4.Write Themes and Styles for everything.
5.Fix the text not wrapping correctly for repo names and descriptions.
6.Add the repos owner's name/make it look nicer.
7.fix the top BLANK repos textView. (I think fixed)
8.images load very slowly, have a system to pre-load the images. (Load the background images at the beginning
so that they are pre-loaded when the user scrolls).
 */
class MainActivity : AppCompatActivity(), OnRepoItemSelectedListener {
    override fun onRepoItemPicked(repo: Repo) {
        //add the other fragment
        currentFrag.onPause()
        currentFrag = RepoFragment(repo)
        fragmentTransaction = fragmentManager.beginTransaction()
        fragmentManager.findFragmentById(R.id.fragment_container)
        fragmentTransaction.replace(R.id.fragment_container, currentFrag,"Repo")
        fragmentTransaction.addToBackStack(null)
        fragmentTransaction.commit()
        changeToolbar(false)
        Log.i("Activity", "Repo selected")
    }
    lateinit var fragmentManager: FragmentManager
    lateinit var fragmentTransaction: FragmentTransaction
    lateinit var currentFrag: Fragment
    lateinit var menu: Menu
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("onCreate", "Created")
        //setContentView(R.layout.activity_main)
        fragmentManager = supportFragmentManager
        fragmentTransaction = fragmentManager.beginTransaction()
        //Initializing the news article fragments
        currentFrag = RepoListFragment()
        fragmentTransaction.add(R.id.fragment_container, currentFrag,"List")
        //fragmentTransaction.addToBackStack(fragmentManager.findFragmentById(R.id.fragment_container)?.tag)
        fragmentTransaction.commit()
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<View>(R.id.toolbar) as Toolbar)

    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        if (menu != null) {
            this.menu = menu
        }
        menuInflater.inflate(R.menu.my_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onResume() {
        super.onResume()
        toolbar.setNavigationOnClickListener(object: View.OnClickListener{
            override fun onClick(p0: View?) {
                Log.i("main","Back button Pressed")
                changeToolbar(true)
                currentFrag = fragmentManager.findFragmentByTag("List")!!
                fragmentManager.popBackStack()
            }
        })
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        Log.i("itemSelected","")
        if(item.itemId == R.id.refreshMenu){
            Log.i("OnRefresh",(currentFrag as RepoListFragment).text.text.toString())
//            CoroutineScope(Dispatchers.IO).launch{
//                TestNetworking().getGitHub(text.getText().toString(),this@RepoListFragment)
//            }
            (currentFrag as RepoListFragment).getNetworkRequest((currentFrag as RepoListFragment).text.getText().toString())
            (currentFrag as RepoListFragment).refresh.setRefreshing(false)
            return true
        }
        else if(item.itemId== R.id.home){
            Log.i("main","Back button Pressed")
            fragmentManager.popBackStack()
            return true
        }
        else {
            return super.onOptionsItemSelected(item)
        }
    }
    private fun changeToolbar(show:Boolean){
        menu.findItem(R.id.refreshMenu).setVisible(show)
        supportActionBar?.setDisplayHomeAsUpEnabled(!show)
        supportActionBar?.setDisplayShowHomeEnabled(!show)
    }
    //function to determine what fragment we are currently on
    fun currentFrag(): Boolean{
        if(currentFrag is RepoListFragment){
            return false
        }
        return true
    }
    fun getCurrentFragment():Fragment{
        return currentFrag
    }
}