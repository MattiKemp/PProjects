package com.example.myapplication

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import GitHub.RepoContainer
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.AdapterView
import android.widget.ImageView
import com.bumptech.glide.Glide

interface AdapterCommunication{
    var position:Int
}
//code from link:developer.android.com/guide/topics/ui/layout/recyclerview
class MyAdapter(private var myDataset: RepoContainer,frag:RepoListFragment): RecyclerView.Adapter<MyAdapter.ViewHolder>(){
    //Provide a ref to the views for each data item.
    //Complex data items may need more than one view per item, and
    //you provide access to all the views for a data item in a view holder
    //In the ex each data item is just a string in this case that is shown in a TextView
    //class MyViewHolder(val textView: TextView): RecyclerView.ViewHolder(textView)
    var clickedView : Int = 0
    //I don't know why I need this instance variable when I already passed frag
    //into the parameter :/
    var frag = frag
    class ViewHolder(itemView:View) : RecyclerView.ViewHolder(itemView){
        var userRepoName: TextView = itemView.findViewById<View>(R.id.userRepoName) as TextView
        var userName: TextView = itemView.findViewById<View>(R.id.userName) as TextView
        var description: TextView = itemView.findViewById<View>(R.id.description) as TextView
        var image: ImageView = itemView.findViewById(R.id.picture) as ImageView
        //v.setOnClickListener(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        //create a new view
        var view = LayoutInflater.from(parent.context).inflate(R.layout.my_text_view, parent, false)
        // set the view's size, margins, padding and layout parameters
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element

        Log.i("BIND VIEW","BOUND")
        holder.itemView.setOnTouchListener(object: View.OnTouchListener{
            override fun onTouch(p0: View?, p1: MotionEvent?): Boolean {
                Log.i("VIEWHOLDER","CLICKED")
                frag.position = position
                return true
            }
        })
        Log.i("MyAdapter","element changed")
        println(position)
        Glide.with(holder.image).load(myDataset.items[position].owner.avatarUrl).into(holder.image)
        holder.userRepoName.text = myDataset.items[position].name + "/"
        holder.userName.text = myDataset.items[position].owner.login
        holder.description.text = myDataset.items[position].description
    }
    fun setMyDataset(myDataset: RepoContainer){
        this.myDataset=myDataset
    }
    //Return the size of your dataset (invoked by layout manager)
    override fun getItemCount() = myDataset.items.size
}