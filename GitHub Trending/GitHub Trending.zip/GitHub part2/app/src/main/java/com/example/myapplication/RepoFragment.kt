package com.example.myapplication

import GitHub.Repo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide

class RepoFragment(repo:Repo) : Fragment() {
    var repoInfo : Repo
    init{
        repoInfo=repo
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        var fragView = inflater.inflate(R.layout.repo_frag, container, false)
        var owner = (fragView?.findViewById<View>(R.id.owner) as TextView)
        var name = (fragView?.findViewById<View>(R.id.name) as TextView)
        var desc = (fragView?.findViewById<View>(R.id.description) as TextView)
        var image = (fragView?.findViewById(R.id.picture) as ImageView)
        owner.text= "Owner: " + repoInfo.owner.login
        name.text = "Name: " + repoInfo.fullName
        desc.text = "Description: " + repoInfo.description
        Glide.with(image).load(repoInfo.owner.avatarUrl).into(image)

        return fragView
    }
}