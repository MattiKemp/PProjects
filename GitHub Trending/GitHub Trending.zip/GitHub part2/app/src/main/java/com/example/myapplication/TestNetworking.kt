package com.example.m

import GitHub.Repo
import GitHub.RepoContainer
import Pokemon.Pokemon
import android.app.Activity
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.myapplication.*
import kotlinx.coroutines.Dispatchers
import retrofit2.*
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import kotlinx.coroutines.*

interface pokemonAPI{
    @GET("pokemon/ditto")
    fun getPokemon(): Call<Pokemon>
}

class TestNetworking {
    fun testNetworking(){
        val TAG = "PokemonAPI call"
        var pokemons = Pokemon()
        val retrofit = Retrofit.Builder().baseUrl("https://pokeapi.co/api/v2/").addConverterFactory(MoshiConverterFactory.create()).build()
        val service = retrofit.create(pokemonAPI::class.java)
        val person = service.getPokemon()
        val k = person.enqueue(object: Callback<Pokemon>{
            override fun onResponse(Call:Call<Pokemon>, response: Response<Pokemon>) {
                Log.i(TAG, "Worked! Got:" + (response.body()?.name))
                if(response.body()==null){

                }
                else {
                    pokemons = response.body()!!
                }
            }
            override fun onFailure(call: Call<Pokemon>, t: Throwable){
                Log.e(TAG,"Failed")
                t.printStackTrace()
            }
        })
    }
    //ideally we would not get all the search results, only the first 10 or so.
    interface githubAPI {
       @GET("repositories?q&sort=stars")
       fun getStar(@Query("q") topic:String): Call<RepoContainer>
    }
    //really need to review coroutines and make sure the code in here is actually doing what it is supposed
    //to do
    fun getGitHub(topic:String,myActivity: RepoListFragment){
        GlobalScope.launch(Dispatchers.Main){
            myActivity.recyclerView.apply { adapter = MyAdapter(RepoContainer(),myActivity)}
            myActivity.myDataset= RepoContainer()
        }
        val TAG = "GitHub call"
        val retrofit = Retrofit.Builder().baseUrl("https://api.github.com/search/").addConverterFactory(MoshiConverterFactory.create()).build()
        val service = retrofit.create(githubAPI::class.java)
        val person = service.getStar(topic)
        val k = person.enqueue(object: Callback<RepoContainer>{
            override fun onResponse(Call:Call<RepoContainer>, response: Response<RepoContainer>) {
                Log.i(TAG, "Worked! Got:" + (response.body()))
                if(response.body()==null){
                    Log.i(TAG,"response was null")
                    myActivity.networkDialog()
                }
                else {
                    GlobalScope.launch(Dispatchers.Main) {
                        myActivity.myDataset = response.body()!!
                        Log.i(TAG, myActivity.myDataset.items.size.toString())
                        myActivity.recyclerView.apply { adapter = MyAdapter(response.body()!!,myActivity) }
                        myActivity.myDataset = response.body()!!
                        myActivity.resetMinutesAgo()
                        }
                    }
                }
            override fun onFailure(call: Call<RepoContainer>, t: Throwable){
                Log.e(TAG,"Failed")
                t.printStackTrace()
                myActivity.networkDialog()
            }
        })
    }
}