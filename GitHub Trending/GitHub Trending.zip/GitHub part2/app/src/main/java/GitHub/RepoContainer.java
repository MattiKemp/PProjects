package GitHub;

import com.squareup.moshi.Json;

import java.util.List;

public class RepoContainer {
    @Json(name = "total_count")
    private int count;
    @Json(name = "incomplete_results")
    private boolean incom_results;
    @Json(name = "items")
    private Repo[] items;
    public RepoContainer(){
        super();
        count = 0;
        incom_results = false;
        Repo[] loading = new Repo[1];
        loading[0]=new Repo();
        loading[0].setName("LOADING...");
        loading[0].setDescription("");
        Owner loadingOwner = new Owner();
        loadingOwner.setAvatarUrl("");
        loading[0].setOwner(loadingOwner);
        items = loading;
    }
    public RepoContainer(int total_count, boolean incomplete_results, Repo[] items){
        super();
        this.count = total_count;
        this.incom_results = incomplete_results;
        this.items = items;
    }
    public int getCount(){
        return count;
    }
    public boolean getIncom_Results(){
        return incom_results;
    }
    public Repo[] getItems(){
        return items;
    }
}
