package Pokemon;


import java.util.List;
import com.squareup.moshi.Json;

import Pokemon.Move_;
import Pokemon.VersionGroupDetail;

public class Move {

    @Json(name = "move")
    private Move_ move;
    @Json(name = "version_group_details")
    private List<VersionGroupDetail> versionGroupDetails = null;

    public Move_ getMove() {
        return move;
    }

    public void setMove(Move_ move) {
        this.move = move;
    }

    public List<VersionGroupDetail> getVersionGroupDetails() {
        return versionGroupDetails;
    }

    public void setVersionGroupDetails(List<VersionGroupDetail> versionGroupDetails) {
        this.versionGroupDetails = versionGroupDetails;
    }

}