package Pokemon;


import com.squareup.moshi.Json;

public class GameIndex {

    @Json(name = "game_index")
    private int gameIndex;
    @Json(name = "version")
    private Version version;

    public int getGameIndex() {
        return gameIndex;
    }

    public void setGameIndex(int gameIndex) {
        this.gameIndex = gameIndex;
    }

    public Version getVersion() {
        return version;
    }

    public void setVersion(Version version) {
        this.version = version;
    }

}