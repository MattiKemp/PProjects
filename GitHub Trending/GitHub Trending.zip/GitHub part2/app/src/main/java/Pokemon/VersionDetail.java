package Pokemon;

import com.squareup.moshi.Json;

public class VersionDetail {

    @Json(name = "rarity")
    private int rarity;
    @Json(name = "version")
    private Version_ version;

    public int getRarity() {
        return rarity;
    }

    public void setRarity(int rarity) {
        this.rarity = rarity;
    }

    public Version_ getVersion() {
        return version;
    }

    public void setVersion(Version_ version) {
        this.version = version;
    }

}