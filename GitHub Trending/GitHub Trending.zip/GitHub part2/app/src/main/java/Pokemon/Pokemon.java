package Pokemon;

import java.util.List;

import com.squareup.moshi.Json;

public class Pokemon {

    @Json(name = "abilities")
    private List<Ability> abilities = null;
    @Json(name = "base_experience")
    private int baseExperience;
    @Json(name = "forms")
    private List<Form> forms = null;
    @Json(name = "game_indices")
    private List<GameIndex> gameIndices = null;
    @Json(name = "height")
    private int height;
    @Json(name = "held_items")
    private List<HeldItem> heldItems = null;
    @Json(name = "id")
    private int id;
    @Json(name = "is_default")
    private boolean isDefault;
    @Json(name = "location_area_encounters")
    private String locationAreaEncounters;
    @Json(name = "moves")
    private List<Move> moves = null;
    @Json(name = "name")
    private String name;
    @Json(name = "order")
    private int order;
    @Json(name = "species")
    private Species species;
    @Json(name = "sprites")
    private Sprites sprites;
    @Json(name = "stats")
    private List<Stat> stats = null;
    @Json(name = "types")
    private List<Type> types = null;
    @Json(name = "weight")
    private int weight;

    public List<Ability> getAbilities() {
        return abilities;
    }

    public void setAbilities(List<Ability> abilities) {
        this.abilities = abilities;
    }

    public int getBaseExperience() {
        return baseExperience;
    }

    public void setBaseExperience(int baseExperience) {
        this.baseExperience = baseExperience;
    }

    public List<Form> getForms() {
        return forms;
    }

    public void setForms(List<Form> forms) {
        this.forms = forms;
    }

    public List<GameIndex> getGameIndices() {
        return gameIndices;
    }

    public void setGameIndices(List<GameIndex> gameIndices) {
        this.gameIndices = gameIndices;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public List<HeldItem> getHeldItems() {
        return heldItems;
    }

    public void setHeldItems(List<HeldItem> heldItems) {
        this.heldItems = heldItems;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isIsDefault() {
        return isDefault;
    }

    public void setIsDefault(boolean isDefault) {
        this.isDefault = isDefault;
    }

    public String getLocationAreaEncounters() {
        return locationAreaEncounters;
    }

    public void setLocationAreaEncounters(String locationAreaEncounters) {
        this.locationAreaEncounters = locationAreaEncounters;
    }

    public List<Move> getMoves() {
        return moves;
    }

    public void setMoves(List<Move> moves) {
        this.moves = moves;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public Species getSpecies() {
        return species;
    }

    public void setSpecies(Species species) {
        this.species = species;
    }

    public Sprites getSprites() {
        return sprites;
    }

    public void setSprites(Sprites sprites) {
        this.sprites = sprites;
    }

    public List<Stat> getStats() {
        return stats;
    }

    public void setStats(List<Stat> stats) {
        this.stats = stats;
    }

    public List<Type> getTypes() {
        return types;
    }

    public void setTypes(List<Type> types) {
        this.types = types;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

}