package Pokemon;

import com.squareup.moshi.Json;

public class Type {

    @Json(name = "slot")
    private int slot;
    @Json(name = "type")
    private Type_ type;

    public int getSlot() {
        return slot;
    }

    public void setSlot(int slot) {
        this.slot = slot;
    }

    public Type_ getType() {
        return type;
    }

    public void setType(Type_ type) {
        this.type = type;
    }

}
