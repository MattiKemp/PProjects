package Pokemon;

import com.squareup.moshi.Json;

public class VersionGroupDetail {

    @Json(name = "level_learned_at")
    private int levelLearnedAt;
    @Json(name = "move_learn_method")
    private MoveLearnMethod moveLearnMethod;
    @Json(name = "version_group")
    private VersionGroup versionGroup;

    public int getLevelLearnedAt() {
        return levelLearnedAt;
    }

    public void setLevelLearnedAt(int levelLearnedAt) {
        this.levelLearnedAt = levelLearnedAt;
    }

    public MoveLearnMethod getMoveLearnMethod() {
        return moveLearnMethod;
    }

    public void setMoveLearnMethod(MoveLearnMethod moveLearnMethod) {
        this.moveLearnMethod = moveLearnMethod;
    }

    public VersionGroup getVersionGroup() {
        return versionGroup;
    }

    public void setVersionGroup(VersionGroup versionGroup) {
        this.versionGroup = versionGroup;
    }

}
