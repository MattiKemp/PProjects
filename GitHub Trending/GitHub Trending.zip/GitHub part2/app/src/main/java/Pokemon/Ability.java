package Pokemon;

import com.squareup.moshi.Json;

import Pokemon.Ability_;

public class Ability {

    @Json(name = "ability")
    private Ability_ ability;
    @Json(name = "is_hidden")
    private boolean isHidden;
    @Json(name = "slot")
    private int slot;

    public Ability_ getAbility() {
        return ability;
    }

    public void setAbility(Ability_ ability) {
        this.ability = ability;
    }

    public boolean isIsHidden() {
        return isHidden;
    }

    public void setIsHidden(boolean isHidden) {
        this.isHidden = isHidden;
    }

    public int getSlot() {
        return slot;
    }

    public void setSlot(int slot) {
        this.slot = slot;
    }

}