package Pokemon;

import com.squareup.moshi.Json;

import Pokemon.Stat_;

public class Stat {

    @Json(name = "base_stat")
    private int baseStat;
    @Json(name = "effort")
    private int effort;
    @Json(name = "stat")
    private Stat_ stat;

    public int getBaseStat() {
        return baseStat;
    }

    public void setBaseStat(int baseStat) {
        this.baseStat = baseStat;
    }

    public int getEffort() {
        return effort;
    }

    public void setEffort(int effort) {
        this.effort = effort;
    }

    public Stat_ getStat() {
        return stat;
    }

    public void setStat(Stat_ stat) {
        this.stat = stat;
    }

}